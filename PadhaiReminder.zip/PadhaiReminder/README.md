# Padhai Reminder (Android)
Silent pop-up study reminders every 10 min (changeable) with Hinglish (80%) / English (20%) taunts.

## Build
1. Open this folder in Android Studio (Koala or newer), let Gradle sync.
2. Connect phone (USB debugging) -> Run, or Build > Build APK(s) to get an installable debug APK.

## First run
- Allow notifications, then allow "Alarms & reminders" when asked.
- Tap "Battery settings" and set the app to Unrestricted / No restrictions.
- Xiaomi/Oppo/Vivo/Realme: also enable Autostart + "Floating/Pop-up notifications" for the app.

## Edit taunts
tools/generate_taunts.py -> change the lists -> run `python3 tools/generate_taunts.py`.
