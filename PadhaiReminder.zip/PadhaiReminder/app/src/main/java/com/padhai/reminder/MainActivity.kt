package com.padhai.reminder

import android.Manifest
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val intervals = listOf(5, 10, 15, 20, 30, 45, 60)
    private val focusMs = 25 * 60_000L
    private var timer: CountDownTimer? = null

    private lateinit var tvStatus: TextView
    private lateinit var tvPreview: TextView
    private lateinit var tvToday: TextView
    private lateinit var tvStreak: TextView
    private lateinit var tvTimer: TextView
    private lateinit var progress: ProgressBar
    private lateinit var btnToggle: Button
    private lateinit var btnStart: Button
    private lateinit var btnEnd: Button
    private lateinit var btnFocus: Button
    private lateinit var etSubject: EditText
    private lateinit var etGoal: EditText
    private lateinit var spInterval: Spinner

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (!granted) Toast.makeText(this, "Notification permission do, warna taunt kaise aayega?", Toast.LENGTH_LONG).show()
            startReminders()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvPreview = findViewById(R.id.tvPreview)
        tvToday = findViewById(R.id.tvToday)
        tvStreak = findViewById(R.id.tvStreak)
        tvTimer = findViewById(R.id.tvTimer)
        progress = findViewById(R.id.progress)
        btnToggle = findViewById(R.id.btnToggle)
        btnStart = findViewById(R.id.btnStart)
        btnEnd = findViewById(R.id.btnEnd)
        btnFocus = findViewById(R.id.btnFocus)
        etSubject = findViewById(R.id.etSubject)
        etGoal = findViewById(R.id.etGoal)
        spInterval = findViewById(R.id.spInterval)

        etSubject.setText(Prefs.subject(this))
        etGoal.setText(Prefs.goalMin(this).toString())

        spInterval.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, intervals.map { "$it min" })
        spInterval.setSelection(intervals.indexOf(Prefs.interval(this)).coerceAtLeast(0))
        spInterval.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val chosen = intervals[pos]
                if (chosen != Prefs.interval(this@MainActivity)) {
                    Prefs.setInterval(this@MainActivity, chosen)
                    if (Prefs.enabled(this@MainActivity)) Scheduler.schedule(this@MainActivity)
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        btnToggle.setOnClickListener {
            saveInputs()
            if (Prefs.enabled(this)) stopReminders() else requestAndStart()
        }
        findViewById<Button>(R.id.btnTest).setOnClickListener {
            saveInputs()
            val t = TauntRepo.next(this)
            tvPreview.text = "“$t”"
            Notifier.show(this, t)
        }
        btnStart.setOnClickListener { pickTime(true) }
        btnEnd.setOnClickListener { pickTime(false) }
        btnFocus.setOnClickListener { if (timer == null) startFocus() else stopFocus(false) }
        findViewById<Button>(R.id.btnBattery).setOnClickListener {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    override fun onResume() {
        super.onResume()
        if (Prefs.enabled(this) && timer == null) Scheduler.schedule(this) // refresh after permission changes
        refresh()
    }

    override fun onPause() {
        super.onPause()
        saveInputs()
    }

    override fun onDestroy() {
        timer?.cancel()
        super.onDestroy()
    }

    private fun saveInputs() {
        Prefs.setSubject(this, etSubject.text.toString().trim())
        val g = etGoal.text.toString().toIntOrNull()
        if (g != null && g > 0) Prefs.setGoalMin(this, g)
    }

    private fun requestAndStart() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        else startReminders()
    }

    private fun startReminders() {
        Prefs.setEnabled(this, true)
        Notifier.ensureChannel(this)
        if (!Scheduler.canExact(this) && Build.VERSION.SDK_INT >= 31) {
            Toast.makeText(this, "Exact timing ke liye 'Alarms & reminders' allow karo", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
        }
        Scheduler.schedule(this)
        refresh()
    }

    private fun stopReminders() {
        Prefs.setEnabled(this, false)
        Scheduler.cancel(this)
        refresh()
    }

    private fun pickTime(isStart: Boolean) {
        val cur = if (isStart) Prefs.startMin(this) else Prefs.endMin(this)
        TimePickerDialog(this, { _, h, m ->
            if (isStart) Prefs.setStartMin(this, h * 60 + m) else Prefs.setEndMin(this, h * 60 + m)
            refresh()
        }, cur / 60, cur % 60, true).show()
    }

    private fun startFocus() {
        saveInputs()
        Prefs.setFocusUntil(this, System.currentTimeMillis() + focusMs)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        btnFocus.text = "Focus rok do"
        timer = object : CountDownTimer(focusMs, 1000) {
            override fun onTick(ms: Long) {
                val s = ms / 1000
                tvTimer.text = "%02d:%02d".format(s / 60, s % 60)
            }
            override fun onFinish() {
                Prefs.addMinutes(this@MainActivity, 25)
                Notifier.show(this@MainActivity,
                    "Shabash! 25 minute ka focus complete ✅ 5 minute break lo, phir wapas aana.", "🎉 Focus complete")
                stopFocus(true)
            }
        }.start()
    }

    private fun stopFocus(finished: Boolean) {
        timer?.cancel()
        timer = null
        Prefs.setFocusUntil(this, 0L)
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        tvTimer.text = "25:00"
        btnFocus.text = "Focus shuru karo"
        if (!finished) Toast.makeText(this, "Focus beech mein chhod diya. Hmm.", Toast.LENGTH_SHORT).show()
        refresh()
    }

    private fun fmtTime(min: Int) = "%02d:%02d".format(min / 60, min % 60)

    private fun refresh() {
        val on = Prefs.enabled(this)
        btnToggle.text = if (on) "⏹ Reminders band karo" else "▶ Reminders shuru karo"
        tvStatus.text = if (on) "ON: har ${Prefs.interval(this)} min mein silent pop-up" else "OFF"
        btnStart.text = "Shuru: ${fmtTime(Prefs.startMin(this))}"
        btnEnd.text = "Khatam: ${fmtTime(Prefs.endMin(this))}"
        btnFocus.text = if (timer == null) "Focus shuru karo" else "Focus rok do"

        val done = Prefs.todayMinutes(this)
        val goal = Prefs.goalMin(this)
        tvToday.text = "$done / $goal min padhai aaj"
        progress.max = goal
        progress.progress = done.coerceAtMost(goal)
        val s = Prefs.streak(this)
        tvStreak.text = if (s > 0) "🔥 Streak: $s din" else "Streak: 0 — aaj goal poora karke shuru karo"
    }
}
