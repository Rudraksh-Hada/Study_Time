package com.padhai.reminder

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("study", Context.MODE_PRIVATE)
    private fun fmt() = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private fun today(): String = fmt().format(Date())
    private fun yesterday(): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -1)
        return fmt().format(cal.time)
    }

    fun enabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun interval(c: Context) = sp(c).getInt("interval", 10)
    fun setInterval(c: Context, v: Int) = sp(c).edit().putInt("interval", v).apply()

    // active hours stored as minutes since midnight (default 06:00 - 23:30)
    fun startMin(c: Context) = sp(c).getInt("start", 360)
    fun endMin(c: Context) = sp(c).getInt("end", 1410)
    fun setStartMin(c: Context, v: Int) = sp(c).edit().putInt("start", v).apply()
    fun setEndMin(c: Context, v: Int) = sp(c).edit().putInt("end", v).apply()

    fun subject(c: Context): String = sp(c).getString("subject", "") ?: ""
    fun setSubject(c: Context, v: String) = sp(c).edit().putString("subject", v).apply()

    fun goalMin(c: Context) = sp(c).getInt("goal", 240)
    fun setGoalMin(c: Context, v: Int) = sp(c).edit().putInt("goal", v).apply()

    fun focusUntil(c: Context) = sp(c).getLong("focusUntil", 0L)
    fun setFocusUntil(c: Context, v: Long) = sp(c).edit().putLong("focusUntil", v).apply()

    fun inActiveHours(c: Context): Boolean {
        val now = Calendar.getInstance()
        val m = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val s = startMin(c)
        val e = endMin(c)
        return if (s <= e) m in s until e else (m >= s || m < e)
    }

    fun todayMinutes(c: Context): Int =
        if (sp(c).getString("day", "") == today()) sp(c).getInt("mins", 0) else 0

    fun addMinutes(c: Context, minutes: Int) {
        val s = sp(c)
        val t = today()
        val total = todayMinutes(c) + minutes
        val e = s.edit().putString("day", t).putInt("mins", total)
        if (total >= goalMin(c) && s.getString("met", "") != t) {
            val streak = if (s.getString("met", "") == yesterday()) s.getInt("streak", 0) + 1 else 1
            e.putInt("streak", streak).putString("met", t)
        }
        e.apply()
    }

    fun streak(c: Context): Int {
        val m = sp(c).getString("met", "")
        return if (m == today() || m == yesterday()) sp(c).getInt("streak", 0) else 0
    }
}
