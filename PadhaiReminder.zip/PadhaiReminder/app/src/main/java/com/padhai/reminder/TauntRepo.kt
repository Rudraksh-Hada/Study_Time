package com.padhai.reminder

import android.content.Context
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.util.Random

/**
 * Picks one random line from the big taunt files (80% Hinglish, 20% English)
 * by seeking to a random byte offset, so the 10 MB files are never fully loaded.
 */
object TauntRepo {
    private val rnd = Random()
    private const val HINGLISH = "taunts_hinglish.txt"
    private const val ENGLISH = "taunts_english.txt"
    private const val FALLBACK = "Padhai karo yaar. Abhi. Isi waqt."

    fun next(c: Context): String {
        val file = if (rnd.nextInt(100) < 80) HINGLISH else ENGLISH
        return randomLine(c, file) ?: FALLBACK
    }

    private fun randomLine(c: Context, name: String): String? {
        return try {
            c.assets.openFd(name).use { afd ->
                val ch = FileInputStream(afd.fileDescriptor).channel
                val window = 600
                val maxOff = (afd.length - window).coerceAtLeast(0L)
                val off = (rnd.nextDouble() * maxOff).toLong()
                ch.position(afd.startOffset + off)
                val bb = ByteBuffer.allocate(window)
                ch.read(bb)
                val a = bb.array()
                val n = bb.position()
                val nl = '\n'.code.toByte()
                var s = 0
                while (s < n && a[s] != nl) s++
                s++ // skip to start of the next full line
                var e = s
                while (e < n && a[e] != nl) e++
                if (e > s) String(a, s, e - s, Charsets.UTF_8) else null
            }
        } catch (ex: Exception) {
            null
        }
    }
}
